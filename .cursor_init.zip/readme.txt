Replace .cursor_init.zip with your full template. This folder becomes .cursor in the project.
