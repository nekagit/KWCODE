Replace .cursor_init.zip with your full template. Contents go to project .cursor/.
